use redis::aio::ConnectionManager;
use sqlx::PgPool;

/// Shared application state. Cloned per request by Axum.
#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
    pub cache: ConnectionManager,
}
