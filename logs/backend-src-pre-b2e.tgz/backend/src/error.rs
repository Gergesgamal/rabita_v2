//! Shared application error type. Every error response is RFC 9457 Problem Details.
//! Server errors are logged in full and return a generic message to the client.

use axum::{
    http::{header, StatusCode},
    response::{IntoResponse, Response},
};
use serde::Serialize;

const GENERIC: &str = "An internal error occurred.";

pub type AppResult<T> = Result<T, AppError>;

/// Machine-readable categories for `AppError::new`.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ErrorCode {
    NotFound,
    InvalidInput,
    InvalidState,
    Conflict,
    RateLimited,
    QuotaExceeded,
    CacheError,
    InternalError,
}

#[derive(Debug)]
pub enum AppError {
    BadRequest(String),
    Unauthorized,
    AuthenticationFailed,
    InvalidToken,
    SessionExpired,
    Forbidden(String),
    NotFound(String),
    Conflict(String),
    Database(String),
    InternalError(String),
    Coded { code: ErrorCode, message: String },
}

impl AppError {
    pub fn new(code: ErrorCode, message: impl Into<String>) -> Self {
        AppError::Coded { code, message: message.into() }
    }

    /// Logs the driver error server-side. The client only ever sees a generic message.
    pub fn database_error(err: &sqlx::Error) -> Self {
        tracing::error!(error = %err, "database error");
        AppError::Database(err.to_string())
    }

    /// (status, machine-readable code, detail)
    fn parts(&self) -> (StatusCode, &'static str, String) {
        match self {
            AppError::BadRequest(m) => (StatusCode::BAD_REQUEST, "invalid_input", m.clone()),
            AppError::Unauthorized => (StatusCode::UNAUTHORIZED, "unauthorized", "Authentication required.".into()),
            AppError::AuthenticationFailed => (StatusCode::UNAUTHORIZED, "authentication_failed", "Invalid credentials.".into()),
            AppError::InvalidToken => (StatusCode::UNAUTHORIZED, "invalid_token", "The token is invalid or expired.".into()),
            AppError::SessionExpired => (StatusCode::UNAUTHORIZED, "session_expired", "The session has expired.".into()),
            AppError::Forbidden(m) => (StatusCode::FORBIDDEN, "forbidden", m.clone()),
            AppError::NotFound(m) => (StatusCode::NOT_FOUND, "not_found", m.clone()),
            AppError::Conflict(m) => (StatusCode::CONFLICT, "conflict", m.clone()),
            AppError::Database(_) => (StatusCode::INTERNAL_SERVER_ERROR, "database_error", GENERIC.into()),
            AppError::InternalError(_) => (StatusCode::INTERNAL_SERVER_ERROR, "internal_error", GENERIC.into()),
            AppError::Coded { code, message } => match code {
                ErrorCode::NotFound => (StatusCode::NOT_FOUND, "not_found", message.clone()),
                ErrorCode::InvalidInput => (StatusCode::BAD_REQUEST, "invalid_input", message.clone()),
                ErrorCode::InvalidState => (StatusCode::CONFLICT, "invalid_state", message.clone()),
                ErrorCode::Conflict => (StatusCode::CONFLICT, "conflict", message.clone()),
                ErrorCode::RateLimited => (StatusCode::TOO_MANY_REQUESTS, "rate_limited", message.clone()),
                ErrorCode::QuotaExceeded => (StatusCode::FORBIDDEN, "quota_exceeded", message.clone()),
                ErrorCode::CacheError => (StatusCode::SERVICE_UNAVAILABLE, "cache_unavailable", GENERIC.into()),
                ErrorCode::InternalError => (StatusCode::INTERNAL_SERVER_ERROR, "internal_error", GENERIC.into()),
            },
        }
    }
}

impl From<sqlx::Error> for AppError {
    fn from(err: sqlx::Error) -> Self {
        AppError::database_error(&err)
    }
}

impl From<redis::RedisError> for AppError {
    fn from(err: redis::RedisError) -> Self {
        tracing::error!(error = %err, "cache error");
        AppError::new(ErrorCode::CacheError, "cache unavailable")
    }
}

impl From<serde_json::Error> for AppError {
    fn from(err: serde_json::Error) -> Self {
        AppError::InternalError(err.to_string())
    }
}

#[derive(Serialize)]
struct Problem<'a> {
    #[serde(rename = "type")]
    kind: &'a str,
    title: &'a str,
    status: u16,
    detail: String,
    code: &'a str,
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, code, mut detail) = self.parts();
        if status.is_server_error() {
            tracing::error!(error = ?self, "request failed");
            detail = GENERIC.to_string();
        }
        let body = Problem {
            kind: "about:blank",
            title: status.canonical_reason().unwrap_or("Error"),
            status: status.as_u16(),
            detail,
            code,
        };
        let bytes = serde_json::to_vec(&body).unwrap_or_default();
        (status, [(header::CONTENT_TYPE, "application/problem+json")], bytes).into_response()
    }
}
