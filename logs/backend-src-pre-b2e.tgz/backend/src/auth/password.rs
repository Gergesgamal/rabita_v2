// backend/src/auth/password.rs

//! Password hashing with Argon2id and HIBP k-anonymity check per D-047.

use crate::error::{AppError, AppResult};
use argon2::{Argon2, PasswordHash, PasswordHasher, PasswordVerifier};
use argon2::password_hash::SaltString;
use sha1::{Sha1, Digest};
use anyhow::anyhow;

/// Password manager with HIBP integration.
pub struct PasswordManager;

impl PasswordManager {
    /// Hash password using Argon2id per D-047.
    pub fn hash_password(password: &str) -> AppResult<String> {
        let salt = SaltString::generate(rand::thread_rng());
        let argon2 = Argon2::default();
        
        argon2
            .hash_password(password.as_bytes(), &salt)
            .map(|hash| hash.to_string())
            .map_err(|e| AppError::InternalError(format!("Password hashing failed: {}", e)))
    }

    /// Verify password against hash.
    pub fn verify_password(password: &str, hash: &str) -> AppResult<bool> {
        let parsed_hash = PasswordHash::new(hash)
            .map_err(|e| AppError::InternalError(format!("Invalid password hash: {}", e)))?;
        
        let argon2 = Argon2::default();
        match argon2.verify_password(password.as_bytes(), &parsed_hash) {
            Ok(()) => Ok(true),
            Err(_) => Ok(false),
        }
    }

    /// Check password against HaveIBeenPwned via k-anonymity per D-047.
    pub async fn check_hibp_breach(password: &str) -> AppResult<bool> {
        // Compute SHA-1 hash
        let mut hasher = Sha1::new();
        hasher.update(password.as_bytes());
        let digest = hasher.finalize();
        let sha1_hex = format!("{:x}", digest).to_uppercase();
        
        // Send first 5 chars only (k-anonymity)
        let prefix = &sha1_hex[..5];
        let suffix = &sha1_hex[5..];
        
        // Call HaveIBeenPwned API
        let client = reqwest::Client::new();
        match client
            .get(&format!("https://api.pwnedpasswords.com/range/{}", prefix))
            .header("User-Agent", "Rabita-Backend")
            .send()
            .await
        {
            Ok(resp) => {
                let text = resp.text().await.unwrap_or_default();
                Ok(text.contains(suffix))
            }
            Err(_) => {
                // Network error: fail open for user experience
                tracing::warn!("HIBP check failed, allowing password");
                Ok(false)
            }
        }
    }

    /// Enforce password policy per D-111: 12+ chars, no complexity rules.
    pub fn validate_password_policy(password: &str) -> AppResult<()> {
        if password.len() < 12 {
            return Err(AppError::BadRequest(
                "Password must be at least 12 characters".to_string(),
            ));
        }
        Ok(())
    }
}
