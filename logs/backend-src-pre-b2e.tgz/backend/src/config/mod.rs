use std::env;

#[derive(Debug, Clone)]
pub struct Config {
    pub database_url: String,
    pub valkey_url: String,
    pub bind_addr: String,
}

impl Config {
    /// Reads configuration from the environment and fails fast on anything missing or invalid.
    pub fn from_env() -> Result<Self, String> {
        Ok(Config {
            database_url: required("DATABASE_URL")?,
            valkey_url: required("VALKEY_URL")?,
            bind_addr: env::var("BIND_ADDR").unwrap_or_else(|_| "0.0.0.0:3000".to_string()),
        })
    }
}

fn required(key: &str) -> Result<String, String> {
    env::var(key).map_err(|_| format!("missing required environment variable {key}"))
}
